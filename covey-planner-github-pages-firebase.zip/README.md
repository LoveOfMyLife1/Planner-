# Task Tracker Planner

A static planner app ready for GitHub Pages.

## Publish on GitHub Pages

1. Create a GitHub repository named `Planner-` under the `loveofmylife1` account, or use your existing `Planner-` repository.
2. Upload these files to the repository root:
   - `index.html`
   - `styles.css`
   - `app.js`
   - `.nojekyll`
   - `.github/workflows/pages.yml`
3. In GitHub, open the repository settings.
4. Go to **Pages**.
5. Under **Build and deployment**, set **Source** to **GitHub Actions**.
6. Push or upload the files to the `main` branch.

After the workflow finishes, the planner should be available at:

```text
https://loveofmylife1.github.io/Planner-/
```

## Sync note

GitHub Pages hosts the planner on the internet, but it cannot save shared task data by itself because it only serves static files. This version uses Firebase Authentication and Firestore for private sync across devices.

## Set up Firebase sync

1. Go to the Firebase console and create a project.
2. Add a web app to the Firebase project.
3. Copy the Firebase web app config into `firebase-config.js`.
4. In **Authentication**, enable **Google** as a sign-in provider.
5. In **Authentication > Settings > Authorized domains**, add:

```text
loveofmylife1.github.io
```

6. In **Firestore Database**, create a database.
7. Publish these Firestore rules:

```text
rules_version = '2';

service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId}/planner/{documentId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

8. Upload the updated files to GitHub and let the Pages workflow run.

After publishing, open the planner, choose **Sign in**, and use the same Google account on your phone and computer.
