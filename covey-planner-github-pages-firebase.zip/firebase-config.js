export const firebaseConfig = {
  apiKey: "AIzaSyBV0xtklad6zItY9EVSmIsPROPC0RuStbs",
  authDomain: "covey-planner-a0c80.firebaseapp.com",
  projectId: "covey-planner-a0c80",
  storageBucket: "covey-planner-a0c80.firebasestorage.app",
  messagingSenderId: "123859797719",
  appId: "1:123859797719:web:ffdc7beb23c739e915d292",
  measurementId: "G-VD5JZLL2WJ",
};

export function isFirebaseConfigured() {
  return Object.values(firebaseConfig).every((value) => value && !value.startsWith("PASTE_"));
}
