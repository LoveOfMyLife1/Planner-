import { initializeApp } from "https://www.gstatic.com/firebasejs/12.13.0/firebase-app.js";
import {
  getAuth,
  getRedirectResult,
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signInWithRedirect,
  signOut,
} from "https://www.gstatic.com/firebasejs/12.13.0/firebase-auth.js";
import {
  doc,
  getDoc,
  getFirestore,
  onSnapshot,
  serverTimestamp,
  setDoc,
} from "https://www.gstatic.com/firebasejs/12.13.0/firebase-firestore.js";
import { firebaseConfig, isFirebaseConfigured } from "./firebase-config.js";

const TASK_KEY = "codex.planner.tasks.v1";
const PREF_KEY = "codex.planner.preferences.v1";
const BACKUP_KEY = "codex.planner.tasks.backup.v1";
const SYNC_INIT_KEY = "codex.taskTracker.sharedSyncInitialized.v1";

const quadrantInfo = {
  1: { title: "Q1", subtitle: "Urgent + important" },
  2: { title: "Q2", subtitle: "Important, not urgent" },
  3: { title: "Q3", subtitle: "Urgent, less important" },
  4: { title: "Q4", subtitle: "Low value" },
};

const state = {
  tasks: readJson(TASK_KEY, []).map(normalizeTask).filter(Boolean),
  preferences: {
    filter: "all",
    sort: "quadrant",
    theme: "light",
    ...readJson(PREF_KEY, {}),
  },
};

if (!["quadrant", "due", "role", "created"].includes(state.preferences.sort)) {
  state.preferences.sort = "quadrant";
}

const form = document.querySelector("#task-form");
const titleInput = document.querySelector("#task-title");
const roleInput = document.querySelector("#task-role");
const dueInput = document.querySelector("#task-due");
const quadrantInput = document.querySelector("#task-quadrant");
const statusInput = document.querySelector("#task-status");
const list = document.querySelector("#task-list");
const emptyState = document.querySelector("#empty-state");
const template = document.querySelector("#task-template");
const sortMode = document.querySelector("#sort-mode");
const filters = document.querySelectorAll(".filter");
const resetButton = document.querySelector("#reset-planner");
const clearDeviceButton = document.querySelector("#clear-device");
const syncNowButton = document.querySelector("#sync-now");
const signInButton = document.querySelector("#sign-in");
const signOutButton = document.querySelector("#sign-out");
const themeToggle = document.querySelector("#theme-toggle");
const recoveryPanel = document.querySelector("#recovery-panel");
const recoveryMessage = document.querySelector("#recovery-message");
const restoreTasksButton = document.querySelector("#restore-tasks");
const exportTasksButton = document.querySelector("#export-tasks");
const copyTasksButton = document.querySelector("#copy-tasks");
const pasteTasksButton = document.querySelector("#paste-tasks");
const importTasksButton = document.querySelector("#import-tasks");
const transferData = document.querySelector("#transfer-data");
const syncStatus = document.querySelector("#sync-status");

let syncAvailable = false;
let saveTimer = null;
let dataVersion = 0;
let auth = null;
let db = null;
let currentUser = null;
let userTasksRef = null;
let unsubscribeTasks = null;
let applyingCloudUpdate = false;
let hasLoadedCloudTasks = false;

document.querySelector("#date-label").textContent = new Intl.DateTimeFormat(undefined, {
  month: "long",
  day: "numeric",
  weekday: "long",
}).format(new Date());

applyPreferences();
render();
initFirebaseSync();

form.addEventListener("submit", (event) => {
  event.preventDefault();
  const title = titleInput.value.trim();
  if (!title) return;

  state.tasks.unshift(
    makeTask({
      title,
      role: roleInput.value,
      dueDate: dueInput.value,
      quadrant: quadrantInput.value,
      status: statusInput.value,
    }),
  );

  titleInput.value = "";
  roleInput.value = "";
  dueInput.value = "";
  quadrantInput.value = "2";
  statusInput.value = "not-started";
  persistTasks();
  render();
  titleInput.focus();
});

syncNowButton.addEventListener("click", () => {
  syncFromFirebase({ mergeLocal: true });
});

signInButton.addEventListener("click", () => {
  signInToFirebase();
});

signOutButton.addEventListener("click", () => {
  signOutOfFirebase();
});

sortMode.addEventListener("change", () => {
  state.preferences.sort = sortMode.value;
  persistPreferences();
  render();
});

filters.forEach((button) => {
  button.addEventListener("click", () => {
    state.preferences.filter = button.dataset.filter;
    persistPreferences();
    applyPreferences();
    render();
  });
});

themeToggle.addEventListener("click", () => {
  state.preferences.theme = state.preferences.theme === "dark" ? "light" : "dark";
  persistPreferences();
  applyPreferences();
});

resetButton.addEventListener("click", () => {
  state.preferences = {
    filter: "all",
    sort: "quadrant",
    theme: "light",
  };
  persistPreferences();
  applyPreferences();
  render();
});

clearDeviceButton.addEventListener("click", () => {
  const confirmed = window.confirm("Clear every task saved on this device?");
  if (!confirmed) return;

  backupTasks();
  state.tasks = [];
  persistTasks();
  render();
});

restoreTasksButton.addEventListener("click", () => {
  const recovered = findRecoverableTasks();
  state.tasks = mergeTasks(state.tasks, recovered.flatMap((candidate) => candidate.tasks));
  persistTasks();
  render();
});

exportTasksButton.addEventListener("click", () => {
  transferData.value = getBackupText();
  transferData.focus();
  transferData.select();
});

copyTasksButton.addEventListener("click", async () => {
  transferData.value = getBackupText();
  transferData.focus();
  transferData.select();

  try {
    await navigator.clipboard.writeText(transferData.value);
    setSyncStatus(syncAvailable ? "online" : "syncing", "Backup copied. Paste it on the other device.");
  } catch {
    setSyncStatus(syncAvailable ? "online" : "syncing", "Backup text is selected. Copy it, then paste on the other device.");
  }
});

pasteTasksButton.addEventListener("click", async () => {
  try {
    transferData.value = await navigator.clipboard.readText();
    transferData.focus();
    setSyncStatus(syncAvailable ? "online" : "syncing", "Backup pasted. Choose Import pasted text to load it.");
  } catch {
    transferData.focus();
    setSyncStatus(syncAvailable ? "online" : "syncing", "Paste backup text into the box, then choose Import pasted text.");
  }
});

importTasksButton.addEventListener("click", () => {
  const imported = extractTasks(readTransferData());
  if (imported.length === 0) {
    window.alert("No tasks were found in the pasted backup text.");
    return;
  }

  backupTasks();
  state.tasks = mergeTasks(state.tasks, imported);
  persistTasks();
  render();
});

function getBackupText() {
  return JSON.stringify(
    {
      exportedAt: new Date().toISOString(),
      tasks: state.tasks,
    },
    null,
    2,
  );
}

function render() {
  const tasks = getVisibleTasks();
  list.innerHTML = "";

  if (state.preferences.sort === "quadrant") {
    Object.keys(quadrantInfo).forEach((quadrant) => {
      const sectionTasks = tasks.filter((task) => task.quadrant === quadrant);
      list.append(createQuadrantSection(quadrant, sectionTasks));
    });
  } else {
    const section = createQuadrantSection("all", tasks);
    list.append(section);
  }

  emptyState.classList.toggle("show", tasks.length === 0);
  renderRecovery();
  updateCounts();
}

function createQuadrantSection(quadrant, tasks) {
  const section = document.createElement("section");
  section.className = `quadrant-section q${quadrant}`;

  const header = document.createElement("div");
  header.className = "quadrant-head";

  const title = document.createElement("h3");
  title.textContent = quadrant === "all" ? "Editable task list" : quadrantInfo[quadrant].title;

  const subtitle = document.createElement("p");
  subtitle.textContent = quadrant === "all" ? "Sorted by your selected view" : quadrantInfo[quadrant].subtitle;

  const count = document.createElement("span");
  count.textContent = String(tasks.length);
  count.setAttribute("aria-label", `${tasks.length} tasks`);

  header.append(title, subtitle, count);
  section.append(header);

  const cards = document.createElement("div");
  cards.className = "quadrant-cards";

  tasks.forEach((task) => cards.append(createTaskCard(task)));
  if (tasks.length === 0) {
    const empty = document.createElement("p");
    empty.className = "quadrant-empty";
    empty.textContent = "No tasks here.";
    cards.append(empty);
  }

  section.append(cards);
  return section;
}

function createTaskCard(task) {
  const item = template.content.firstElementChild.cloneNode(true);
  const statusMark = item.querySelector(".status-mark");
  const title = item.querySelector(".edit-title");
  const role = item.querySelector(".edit-role");
  const due = item.querySelector(".edit-due");
  const quadrant = item.querySelector(".edit-quadrant");
  const status = item.querySelector(".edit-status");
  const notes = item.querySelector(".edit-notes");
  const deleteButton = item.querySelector(".delete-task");

  item.classList.toggle("done", task.status === "completed");
  item.dataset.status = task.status;
  item.dataset.quadrant = task.quadrant;
  if (statusMark) {
    statusMark.textContent = getStatusIcon(task.status);
    statusMark.setAttribute("title", getStatusLabel(task.status));
  }
  title.value = task.title;
  role.value = task.role;
  due.value = task.dueDate;
  quadrant.value = task.quadrant;
  if (status) status.value = task.status;
  notes.value = task.notes;

  title.addEventListener("input", () => updateTask(task.id, { title: title.value }, false));
  title.addEventListener("blur", () => {
    if (!title.value.trim()) title.value = task.title || "Untitled task";
    updateTask(task.id, { title: title.value });
  });
  role.addEventListener("input", () => updateTask(task.id, { role: role.value }, false));
  role.addEventListener("blur", () => persistTasks());
  due.addEventListener("change", () => updateTask(task.id, { dueDate: due.value }));
  quadrant.addEventListener("change", () => updateTask(task.id, { quadrant: quadrant.value }));
  if (status) {
    status.addEventListener("change", () => updateTask(task.id, { status: status.value }));
  }
  notes.addEventListener("input", () => updateTask(task.id, { notes: notes.value }, false));
  notes.addEventListener("blur", () => persistTasks());

  deleteButton.addEventListener("click", () => {
    backupTasks();
    state.tasks = state.tasks.filter((candidate) => candidate.id !== task.id);
    persistTasks();
    render();
  });

  return item;
}

function updateTask(id, patch, shouldRender = true) {
  const task = state.tasks.find((candidate) => candidate.id === id);
  if (!task) return;

  Object.assign(task, patch, { updatedAt: Date.now() });
  if (typeof task.title === "string") task.title = task.title.trimStart();
  task.quadrant = normalizeQuadrant(task.quadrant);
  task.status = normalizeStatus(task.status);
  task.done = task.status === "completed";
  persistTasks();
  if (Object.prototype.hasOwnProperty.call(patch, "status")) {
    setSyncStatus(
      syncAvailable ? "syncing" : "offline",
      `${getStatusLabel(task.status)} saved${syncAvailable ? " and syncing..." : " locally."}`,
    );
  }
  if (shouldRender) render();
}

function getVisibleTasks() {
  const filtered = state.tasks.filter((task) => {
    if (state.preferences.filter === "open") return task.status !== "completed";
    if (state.preferences.filter === "done") return task.status === "completed";
    if (["not-started", "in-progress", "completed"].includes(state.preferences.filter)) {
      return task.status === state.preferences.filter;
    }
    return true;
  });

  return [...filtered].sort((a, b) => {
    if (state.preferences.sort === "due") {
      return (a.dueDate || "9999-99-99").localeCompare(b.dueDate || "9999-99-99");
    }

    if (state.preferences.sort === "role") {
      return (a.role || "zzz").localeCompare(b.role || "zzz") || b.createdAt - a.createdAt;
    }

    if (state.preferences.sort === "quadrant") {
      return Number(a.quadrant) - Number(b.quadrant) || (a.dueDate || "9999-99-99").localeCompare(b.dueDate || "9999-99-99");
    }

    return b.createdAt - a.createdAt;
  });
}

function updateCounts() {
  const done = state.tasks.filter((task) => task.status === "completed").length;
  document.querySelector("#total-count").textContent = state.tasks.length;
  document.querySelector("#open-count").textContent = state.tasks.length - done;
  document.querySelector("#done-count").textContent = done;
}

function applyPreferences() {
  document.documentElement.dataset.theme = state.preferences.theme;
  sortMode.value = state.preferences.sort;
  filters.forEach((button) => {
    button.classList.toggle("active", button.dataset.filter === state.preferences.filter);
  });
}

function persistTasks() {
  dataVersion += 1;
  localStorage.setItem(TASK_KEY, JSON.stringify(state.tasks));
  queueCloudSave();
}

function initFirebaseSync() {
  if (!isFirebaseConfigured()) {
    syncAvailable = false;
    setSyncStatus("offline", "Local only. Add Firebase settings in firebase-config.js to enable phone sync.");
    return;
  }

  try {
    const app = initializeApp(firebaseConfig);
    auth = getAuth(app);
    db = getFirestore(app);

    getRedirectResult(auth).catch(() => {
      setSyncStatus("offline", "Sign-in could not finish. Check Firebase authorized domains.");
    });

    onAuthStateChanged(auth, (user) => {
      currentUser = user;
      signInButton.hidden = Boolean(user);
      signOutButton.hidden = !user;

      if (!user) {
        stopCloudSubscription();
        syncAvailable = false;
        setSyncStatus("offline", "Sign in with Google to sync planner tasks across devices.");
        return;
      }

      userTasksRef = doc(db, "users", user.uid, "planner", "tasks");
      subscribeToCloudTasks();
    });
  } catch {
    syncAvailable = false;
    setSyncStatus("offline", "Firebase could not start. Check firebase-config.js.");
  }
}

async function signInToFirebase() {
  if (!auth) {
    setSyncStatus("offline", "Add Firebase settings before signing in.");
    return;
  }

  const provider = new GoogleAuthProvider();
  setSyncStatus("syncing", "Opening Google sign-in...");

  try {
    await signInWithPopup(auth, provider);
  } catch {
    await signInWithRedirect(auth, provider);
  }
}

async function signOutOfFirebase() {
  if (!auth) return;
  await signOut(auth);
}

function subscribeToCloudTasks() {
  stopCloudSubscription();
  hasLoadedCloudTasks = false;
  setSyncStatus("syncing", "Connecting planner sync...");

  unsubscribeTasks = onSnapshot(
    userTasksRef,
    (snapshot) => {
      const cloudTasks = extractTasks(snapshot.exists() ? snapshot.data() : {});
      const mergedTasks = mergeTasks(cloudTasks, state.tasks);
      const shouldPushMergedTasks =
        !hasLoadedCloudTasks && JSON.stringify(mergedTasks) !== JSON.stringify(cloudTasks);
      applyingCloudUpdate = true;
      state.tasks = hasLoadedCloudTasks ? cloudTasks : mergedTasks;
      localStorage.setItem(SYNC_INIT_KEY, "true");
      localStorage.setItem(TASK_KEY, JSON.stringify(state.tasks));
      dataVersion += 1;
      applyingCloudUpdate = false;
      hasLoadedCloudTasks = true;
      syncAvailable = true;
      render();
      if (shouldPushMergedTasks) saveTasksToCloud();
      setSyncStatus("online", `Synced as ${currentUser.displayName || currentUser.email || "Google user"}.`);
    },
    () => {
      syncAvailable = false;
      setSyncStatus("offline", "Sync paused. Check Firebase rules and your connection.");
    },
  );
}

function stopCloudSubscription() {
  if (unsubscribeTasks) unsubscribeTasks();
  unsubscribeTasks = null;
  userTasksRef = null;
  hasLoadedCloudTasks = false;
}

async function syncFromFirebase({ mergeLocal }) {
  if (!userTasksRef) {
    setSyncStatus("offline", "Sign in to sync planner tasks across devices.");
    return;
  }

  setSyncStatus("syncing", "Syncing planner tasks...");

  try {
    const snapshot = await getDoc(userTasksRef);
    const cloudTasks = extractTasks(snapshot.exists() ? snapshot.data() : {});
    state.tasks = mergeLocal ? mergeTasks(cloudTasks, state.tasks) : cloudTasks;
    localStorage.setItem(TASK_KEY, JSON.stringify(state.tasks));
    dataVersion += 1;
    render();
    await saveTasksToCloud();
  } catch {
    syncAvailable = false;
    setSyncStatus("offline", "Sync paused. Changes are saved locally on this device.");
  }
}

function queueCloudSave() {
  if (!syncAvailable || applyingCloudUpdate) return;
  window.clearTimeout(saveTimer);
  saveTimer = window.setTimeout(() => {
    saveTasksToCloud();
  }, 250);
}

async function saveTasksToCloud() {
  if (!syncAvailable || !userTasksRef || applyingCloudUpdate) return;

  try {
    await setDoc(userTasksRef, {
      tasks: state.tasks,
      updatedAt: serverTimestamp(),
      ownerUid: currentUser?.uid || "",
    });
    setSyncStatus("online", "Synced across desktop and phone.");
  } catch {
    syncAvailable = false;
    setSyncStatus("offline", "Sync paused. Changes are saved locally on this device.");
  }
}

function setSyncStatus(status, message) {
  syncStatus.textContent = message;
  syncStatus.classList.toggle("online", status === "online");
  syncStatus.classList.toggle("offline", status === "offline");
}

function backupTasks() {
  if (state.tasks.length === 0) return;
  localStorage.setItem(
    BACKUP_KEY,
    JSON.stringify({
      backedUpAt: new Date().toISOString(),
      tasks: state.tasks,
    }),
  );
}

function persistPreferences() {
  localStorage.setItem(PREF_KEY, JSON.stringify(state.preferences));
}

function readJson(key, fallback) {
  try {
    const value = localStorage.getItem(key);
    return value ? JSON.parse(value) : fallback;
  } catch {
    return fallback;
  }
}

function readTransferData() {
  try {
    return JSON.parse(transferData.value);
  } catch {
    return transferData.value
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean);
  }
}

function renderRecovery() {
  const recovered = findRecoverableTasks();
  const count = recovered.reduce((sum, candidate) => sum + candidate.tasks.length, 0);

  recoveryPanel.hidden = state.tasks.length > 0 || count === 0;
  if (recoveryPanel.hidden) return;

  const sourceText = recovered.length === 1 ? "1 saved source" : `${recovered.length} saved sources`;
  const taskText = count === 1 ? "1 task" : `${count} tasks`;
  recoveryMessage.textContent = `Found ${taskText} in ${sourceText} on this browser.`;
}

function findRecoverableTasks() {
  const candidates = [];

  for (let index = 0; index < localStorage.length; index += 1) {
    const key = localStorage.key(index);
    if (!key || key === PREF_KEY) continue;

    const value = readJson(key, null);
    const tasks = mergeTasks([], extractTasks(value).filter((task) => task.title));

    if (tasks.length > 0 && (key !== TASK_KEY || state.tasks.length === 0)) {
      candidates.push({ key, tasks });
    }
  }

  return candidates;
}

function extractTasks(value) {
  if (!value) return [];

  if (Array.isArray(value)) {
    return value.map(normalizeTask).filter(Boolean);
  }

  if (typeof value !== "object") return [];

  const nestedKeys = ["tasks", "todos", "items", "list", "entries", "plans"];
  return nestedKeys.flatMap((key) => extractTasks(value[key]));
}

function normalizeTask(item) {
  if (!item) return null;

  if (typeof item === "string") {
    return makeTask({ title: item });
  }

  if (typeof item !== "object") return null;

  const title = item.title || item.text || item.name || item.task || item.label || item.content;
  if (typeof title !== "string" || title.trim().length === 0) return null;

  return makeTask({
    id: typeof item.id === "string" ? item.id : crypto.randomUUID(),
    title,
    role: item.role || item.context || "",
    dueDate: normalizeDateInput(item.dueDate || item.due || item.date),
    quadrant: item.quadrant || priorityToQuadrant(item.priority || item.importance),
    status: normalizeStatus(item.status || item.state || legacyDoneToStatus(item)),
    notes: item.notes || item.note || item.description || "",
    createdAt: normalizeDate(item.createdAt || item.created),
    updatedAt: normalizeDate(item.updatedAt || item.updated),
  });
}

function makeTask(task) {
  return {
    id: task.id || crypto.randomUUID(),
    title: String(task.title || "Untitled task").trim(),
    role: String(task.role || "").trim(),
    dueDate: normalizeDateInput(task.dueDate),
    quadrant: normalizeQuadrant(task.quadrant),
    status: normalizeStatus(task.status),
    notes: String(task.notes || ""),
    done: normalizeStatus(task.status) === "completed",
    createdAt: task.createdAt || Date.now(),
    updatedAt: task.updatedAt || Date.now(),
  };
}

function mergeTasks(existing, incoming) {
  const byIdentity = new Map();

  [...existing, ...incoming].forEach((task) => {
    const normalized = makeTask(task);
    const key =
      normalized.id ||
      `${normalized.title.toLowerCase()}|${normalized.role.toLowerCase()}|${normalized.dueDate}|${normalized.quadrant}`;
    const current = byIdentity.get(key);

    if (!current || Number(normalized.updatedAt || 0) >= Number(current.updatedAt || 0)) {
      byIdentity.set(key, normalized);
    }
  });

  return Array.from(byIdentity.values()).sort((a, b) => Number(b.createdAt || 0) - Number(a.createdAt || 0));
}

function normalizeQuadrant(value) {
  const quadrant = String(value || "2").match(/[1-4]/)?.[0];
  return quadrant || "2";
}

function normalizeStatus(value) {
  const status = String(value || "not-started").toLowerCase().trim();
  if (["completed", "complete", "done", "finished"].includes(status)) return "completed";
  if (["in-progress", "in progress", "progress", "started", "working"].includes(status)) return "in-progress";
  return "not-started";
}

function legacyDoneToStatus(item) {
  return item.done || item.completed || item.checked || item.finished ? "completed" : "not-started";
}

function getStatusIcon(status) {
  if (status === "completed") return "\u2713";
  if (status === "in-progress") return "\u2500";
  return "\u25A1";
}

function getStatusLabel(status) {
  if (status === "completed") return "Completed";
  if (status === "in-progress") return "In progress";
  return "Not started";
}

function priorityToQuadrant(value) {
  const priority = String(value || "").toLowerCase();
  if (priority === "high") return "1";
  if (priority === "low") return "4";
  return "2";
}

function normalizeDateInput(value) {
  if (typeof value !== "string") return "";
  const direct = value.match(/^\d{4}-\d{2}-\d{2}$/);
  if (direct) return value;

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString().slice(0, 10);
}

function normalizeDate(value) {
  const date = new Date(value);
  const time = date.getTime();
  return Number.isFinite(time) ? time : Date.now();
}
